#include <stdio.h>

int main(void)
{

    int A[3][2]={0,};
    int B[2][2]={0,};

    printf("A 입력:  ");
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<2;j++)
        {
            scanf("%d",&A[i][j]);
        }
    }

    printf("B 입력:  ");

    for(int i=0;i<2;i++)
    {
        for(int j=0;j<2;j++)
        {
            scanf("%d",&B[i][j]);
        }
    }
    for(int i=0;i<3;i++)
    {
        for(int j=0;j<1;j++)
        {
            printf("%d   %d",A[i][j]*B[i][j]+A[i][j+1]*B[i+1][j],A[i][j]*B[i][j+1]+A[i][j+1]*B[i+1][j+1]);
        }
        printf("\n");
    }

    
}