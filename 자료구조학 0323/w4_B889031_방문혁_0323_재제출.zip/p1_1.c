#include <stdio.h>


int main (void) 
{
    int sum,x,y,z;

    x=10;
    y=20;
    z=30;

    sum=x+y+z;

    printf("sum = %d",sum);

    return 0;
}  
