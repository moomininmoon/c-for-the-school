#include <stdio.h>
void sum1(int *x,int *y);
int sum2(int *x,int *y);
int main(void)
{
    int x=5,y=4,sum;
    sum=sum2(&x,&y);
    sum1(&x,&y);

    printf("sum1의 결과 : %d\n",x);
    printf("sum2의 결과 : %d",sum);
}

void sum1(int *x,int *y)
{
    *x += *y;
}
int sum2(int *x,int *y)
{

    return *x+*y;
}