#include <stdio.h>

int main()
{
    int *p,*q,*r;
    int x,y,z,sum;

    x=10;
    y=20;
    z=30;
    p=&x;
    q=&y;
    r=&z;
    *p+=*q;
    *p+=*r;
    sum=*p;
    printf("sum = %d",sum);

    return 0;
}